@extends('layouts.app')
@section('title', 'Pelatihan · Monitoring')

@section('content')
  <div class="card-glass" style="padding:12px">
    <h2 class="m-0" style="margin:0 0 6px 0">Pelatihan · Monitoring</h2>
    <p class="muted" style="margin:0 0 12px 0">Coming Soon</p>

    <div class="alert" style="margin:0">Under Development
    </div>
  </div>
@endsection
